import { Injectable } from '@angular/core';
import {User} from "./common/Type";

@Injectable({
  providedIn: 'root'
})
export class StateService {
  userInfo:User
  constructor() { }
  getUserInfo():User{
    return this.userInfo
  }
  setUserInfo(userInfo:User){
    this.userInfo = userInfo
  }
}
