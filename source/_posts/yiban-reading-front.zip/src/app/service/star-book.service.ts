import {Inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {API_CONFIG} from "./service.module";
import {map} from "rxjs/operators";
import {Observable} from "rxjs";
import {Book} from "./common/Type";

@Injectable({
  providedIn: 'root'
})
export class StarBookService {

  constructor(private http: HttpClient, @Inject(API_CONFIG) private uri: string) {

  }

  /**
   * 标星或者取消标星
   * @param openId
   * @param bookId
   */
  starOrUnstarBook(openId: number, bookId: number) {
    return  this.http.get(this.uri + "starBook" + "/" + openId + "/" + bookId).pipe(map(
      (res) => res
    ))
  }


  /**
   * 得到用户收藏的书
   */
  getUserStar(openId: number): Observable<Book[]> {
    return this.http.get(this.uri + "getUserStar" + "/" + openId).pipe(map(
      (res: { data: { book: Book[] } }) => res.data.book
    ))
  }

  /**
   * 判断该书是否被该用户收藏
   */
  isSarBook(openId: number, bookId: number):Observable<boolean> {
    return  this.http.get(this.uri + "isSarBook" + "/" + openId + "/" + bookId).pipe(map(
      (res:{data:{isStar:boolean}}) => {
        return res.data.isStar
      }

    ))
  }
}
