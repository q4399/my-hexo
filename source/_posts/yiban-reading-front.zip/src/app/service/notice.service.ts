import {Inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {API_CONFIG} from "./service.module";
import {map} from "rxjs/operators";
import {Observable} from "rxjs";
import {Notice} from "./common/Type";

@Injectable({
  providedIn: 'root'
})
export class NoticeService {

  constructor(private http: HttpClient, @Inject(API_CONFIG) private uri: string) { }

  //获得通知
  getOneNotice():Observable<Notice[]>{
    return this.http.get(this.uri+"getOneNotice").pipe(map(
      (res:{data:{notice:Notice[]}})=>res.data.notice
    ))
  }
}
