import {InjectionToken, NgModule} from '@angular/core';


export const API_CONFIG = new InjectionToken('ApiConfigToken');

@NgModule({
  declarations: [],
  imports: [],
  providers: [
    //www.mtxympc.cn 配置环境
    {provide: API_CONFIG, useValue: 'http://localhost:8384/'}
    // {provide: API_CONFIG, useValue: 'http://www.mtxympc.cn:8384/'}
  ],
})
export class ServiceModule { }
